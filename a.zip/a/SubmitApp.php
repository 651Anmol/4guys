<?php
session_start();
require_once('connection.php');

if(isset($_POST['submit'])){
    $_SESSION['VIN'] =$_POST['VIN']; 
    $_SESSION['period'] =$_POST['period']; 
    $_SESSION['interest'] =$_POST['interest']; 
    $_SESSION['method'] =$_POST['method'];  
    $_SESSION['down'] =$_POST['down']; 
    $check_query = "SELECT VIN FROM CustomerCar WHERE VIN = 'VIN'";
    $check_result = mysqli_query($con, $check_query);
    
    if (!$check_result || mysqli_num_rows($check_result) === 0) {
        echo "Error: The referenced record does not exist in the Cars table.";
    } else {
$query= "INSERT INTO CustomerCar(VIN, period, interest, method, down)";
$query .= " VALUES ('$_SESSION[VIN]', '$_SESSION[period]', '$_SESSION[interest]', '$_SESSION[method]', '$_SESSION[down]' );";
$result = mysqli_query($con,$query);

if($result){
    move_uploaded_file($_FILES['fileToUpload']['tmp_name'], "$file");
    header('location:main.php');
}

}
}
?>
<!DOCTYPE html>
<html>
    <head>
    <script>
        function showPopup() {
            alert("Your Request was received our agent will reach out to you with your selected preferences");
        }
    </script>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
    </head>
<body>
<nav class="navbar navbar-light navbar-expand-md sticky-top navbar-shrink py-3" id="mainNav">
        <div class="container"><a  class="navbar-brand d-flex align-items-center" href="main.php"><span class="bs-icon-sm bs-icon-circle bs-icon-primary shadow d-flex justify-content-center align-items-center me-2 bs-icon"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" class="bi bi-bezier">
                        <path fill-rule="evenodd" d="M0 10.5A1.5 1.5 0 0 1 1.5 9h1A1.5 1.5 0 0 1 4 10.5v1A1.5 1.5 0 0 1 2.5 13h-1A1.5 1.5 0 0 1 0 11.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm10.5.5A1.5 1.5 0 0 1 13.5 9h1a1.5 1.5 0 0 1 1.5 1.5v1a1.5 1.5 0 0 1-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zM6 4.5A1.5 1.5 0 0 1 7.5 3h1A1.5 1.5 0 0 1 10 4.5v1A1.5 1.5 0 0 1 8.5 7h-1A1.5 1.5 0 0 1 6 5.5v-1zM7.5 4a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"></path>
                        <path d="M6 4.5H1.866a1 1 0 1 0 0 1h2.668A6.517 6.517 0 0 0 1.814 9H2.5c.123 0 .244.015.358.043a5.517 5.517 0 0 1 3.185-3.185A1.503 1.503 0 0 1 6 5.5v-1zm3.957 1.358A1.5 1.5 0 0 0 10 5.5v-1h4.134a1 1 0 1 1 0 1h-2.668a6.517 6.517 0 0 1 2.72 3.5H13.5c-.123 0-.243.015-.358.043a5.517 5.517 0 0 0-3.185-3.185z"></path>
                    </svg></span><span>AbbyLending</span></a><button data-bs-toggle="collapse" class="navbar-toggler"  data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        </div>
    </nav>
<form action="SubmitApp.php" method="post" enctype="multipart/form-data" onsubmit="showPopup()">
<div class= "inputholder">
    <div class="inputs">
        <label for="vin">VIN Number &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</label>
        <input type="text" id="vin" name = "VIN" placeholder="VIN">
        </div>
    <div class="inputs">
    <label for="period">Period of Loan &nbsp; &nbsp; &nbsp; &nbsp;</label>
        <input type="text" id="period" name = "period" placeholder="period">
        </div>
    <div class="inputs">
    <label for="method">Payment Method &nbsp; </label>
        <input type="text" id="method" name = "method" placeholder="method">
        </div>
    
    <div class="inputs">
    <label for="down">Down Payment &nbsp; &nbsp; &nbsp; </label>
        <input type="text" id="down" name = "down" placeholder="down payment">
        </div>
        <div class="inputs same" style=" margin-bottom:10px;">
    <label for="interest">Interest Rate &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</label>
    <select name="interest" id="interest">
         <option value="4% for 2 years">4% for 2 years</option>
         <option value="5% for 4 years">5% for 4 years</option>
         <option value="5.5% for 5 years">5.5% for 5 years</option>
         <option value="6% for 6 years">6% for 6 years</option>
    </select>
        </div>
        <div>
            <button type="submit" name = "submit">Send Information</button>
        </div>
    </div>  

</form>

</body>
</html>