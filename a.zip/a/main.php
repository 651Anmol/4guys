<!DOCTYPE html>
<html lang="en">
<?php


require_once 'connection.php';
session_start();
$_SESSION['isloggedin']=1;
?>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Home - AbbyLending</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Montserrat:400,700&amp;display=swap">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Kaushan+Script&amp;display=swap">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/animate.min.css">
    <link rel="stylesheet" href="assets/css/Lightbox-Gallery-baguetteBox.min.css">
    <link rel="stylesheet" href="style1.css">
    <style>
        body{
            margin-top: 100px;
        }
    </style>
</head>

<body id="page-top" data-bs-spy="scroll" data-bs-target="#mainNav" data-bs-offset="54">
    <nav class="navbar navbar-dark navbar-expand-lg fixed-top bg-dark" id="mainNav">
        <div class="container"><a class="navbar-brand" href="#page-top">AbbyLending</a><button data-bs-toggle="collapse" data-bs-target="#navbarResponsive" class="navbar-toggler navbar-toggler-right" type="button" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation"><i class="fa fa-bars"></i></button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto text-uppercase">
                    <li class="nav-item"><a class="nav-link" href="SubmitApp.php">Submit Application</a></li>
                    <li class="nav-item"><a class="nav-link" href="AddCar.php">Add Your Car</a></li>
                    <li class="nav-item"><a class="nav-link" href="logout.php">logout</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <main>
        <h1> New Vehicles for sale.</h1>
<div>Whether you're on the lookout for a new vehicle or want to get your vehicle sold we help you in every way. <br> Click Submit Application to get a new car financed or click sell your Car to sell your car, rest is on us.</div>
<div>
    <?php

    
    $query1 = "SELECT * FROM Cars";
    $res = mysqli_query($con, $query1);
    while($row = mysqli_fetch_assoc($res)){

        echo '<form action ="" method = "post">';
            echo '<div class = "box">';
            echo '<section>';
                $output = "<div><img src = '".$row['image']."' style = 'width; 200px; height:200px'></div>";
                echo $output;
            echo '</section>';
            echo '<section>';
                echo' <div class = "name ints" >'.'Model: '.$row['name'].'</div>';
                echo' <div class = "address ints" >'.'make: '.$row['make'].'</div>';
                echo' <div class = "city ints" >'.'mileage: '.$row['mileage'].'</div>';
                echo' <div class = "price ints" >'.'price: '.$row['price'].'</div>';
                echo' <div class = "year ints" >'.'year: '.$row['year'].'</div>';
                echo' <div class = "seller ints" >'.'seller: '.$row['seller'].'</div>';
                echo' <div class = "VIN ints" >'.'VIN: '.$row['VIN'].'</div>';
echo'<div class = "line">';
                echo'<a class="button1" href ="delete.php?name='.$row['name'].'">Mark Sold</a>';
                echo '<a class = "button1" href ="SubmitApp.php">Select</a>';
echo'</div>';
            echo '</section>';
            echo '</div>';
      echo '</form>';
    }
    

    ?>
</div>
    </main>
</body>