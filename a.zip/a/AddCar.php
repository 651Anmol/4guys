<?php
session_start();
require_once('connection.php');
if(isset($_POST['submit'])){
    $_SESSION['name'] =$_POST['name']; 
    $_SESSION['make'] =$_POST['make']; 
    $_SESSION['mileage'] =$_POST['mileage']; 
    $_SESSION['price'] =$_POST['price']; 
    $_SESSION['year'] =$_POST['year']; 
    $_SESSION['seller'] =$_POST['seller']; 
    $_SESSION['VIN'] =$_POST['VIN']; 
$file = $_FILES['fileToUpload']['name'];
$query= "INSERT INTO Cars(image, name, make, mileage, price, year, seller, VIN)";
$query .= " VALUES ('$file', '$_SESSION[name]', '$_SESSION[make]', '$_SESSION[mileage]', '$_SESSION[price]', '$_SESSION[year]', '$_SESSION[seller]','$_SESSION[VIN]' );";
$result = mysqli_query($con,$query);

if($result){
    move_uploaded_file($_FILES['fileToUpload']['tmp_name'], "$file");
    header('location:main.php');
}

}

?>
<!DOCTYPE html>
<html>
    <head>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Inter:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&amp;display=swap">
    </head>
<body>
<nav class="navbar navbar-light navbar-expand-md sticky-top navbar-shrink py-3" id="mainNav">
        <div class="container"><a  class="navbar-brand d-flex align-items-center" href="main.php"><span class="bs-icon-sm bs-icon-circle bs-icon-primary shadow d-flex justify-content-center align-items-center me-2 bs-icon"><svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" fill="currentColor" viewBox="0 0 16 16" class="bi bi-bezier">
                        <path fill-rule="evenodd" d="M0 10.5A1.5 1.5 0 0 1 1.5 9h1A1.5 1.5 0 0 1 4 10.5v1A1.5 1.5 0 0 1 2.5 13h-1A1.5 1.5 0 0 1 0 11.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zm10.5.5A1.5 1.5 0 0 1 13.5 9h1a1.5 1.5 0 0 1 1.5 1.5v1a1.5 1.5 0 0 1-1.5 1.5h-1a1.5 1.5 0 0 1-1.5-1.5v-1zm1.5-.5a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1zM6 4.5A1.5 1.5 0 0 1 7.5 3h1A1.5 1.5 0 0 1 10 4.5v1A1.5 1.5 0 0 1 8.5 7h-1A1.5 1.5 0 0 1 6 5.5v-1zM7.5 4a.5.5 0 0 0-.5.5v1a.5.5 0 0 0 .5.5h1a.5.5 0 0 0 .5-.5v-1a.5.5 0 0 0-.5-.5h-1z"></path>
                        <path d="M6 4.5H1.866a1 1 0 1 0 0 1h2.668A6.517 6.517 0 0 0 1.814 9H2.5c.123 0 .244.015.358.043a5.517 5.517 0 0 1 3.185-3.185A1.503 1.503 0 0 1 6 5.5v-1zm3.957 1.358A1.5 1.5 0 0 0 10 5.5v-1h4.134a1 1 0 1 1 0 1h-2.668a6.517 6.517 0 0 1 2.72 3.5H13.5c-.123 0-.243.015-.358.043a5.517 5.517 0 0 0-3.185-3.185z"></path>
                    </svg></span><span>AbbyLending</span></a><button data-bs-toggle="collapse" class="navbar-toggler"  data-bs-target="#navcol-1"><span class="visually-hidden">Toggle navigation</span><span class="navbar-toggler-icon"></span></button>
        </div>
    </nav>
<form action="AddCar.php" method="post" enctype="multipart/form-data">
<div class= "inputholder">
    <div class = "input1" >
        Select image to upload:
    <input type="file" name="fileToUpload" id="fileToUpload">
        </div>
    <div class="inputs">
        <label for="name">Car Model: &nbsp; &nbsp; &nbsp; &nbsp;</label>
        <input type="text" name = "name" placeholder="Name" id="name">
        </div>
    <div class="inputs">
        <label for="VIN">VIN Number:&nbsp; &nbsp;</label>
        <input type="text" name = "VIN" placeholder="VIN" id="VIN">
        </div>
    <div class="inputs">
    <label for="name">Make: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</label>
        <input type="text" name = "make" placeholder="Make" id="make">
        </div>
    <div class="inputs">
        <label for="name">Mileage: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</label>
        <input type="text" name = "mileage" placeholder="Mileage" id="mileage">
        </div>
    <div class="inputs">
        <label for="name">Price: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</label>
        <input type="text" name = "price" id="price" placeholder="Price">
        </div>
    <div class="inputs">
        <label for="name">Year: &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp;</label>
        <input type="text" name = "year" id="year" placeholder="built year">
        </div>
    <div class="inputs">
        <label for="name">Your Name: &nbsp; &nbsp; </label>
        <input type="text" name = "seller" id="seller" placeholder="Seller Name">
        </div>
        <div>
            <button type="submit" name = "submit">Submit</button>
        </div>
    </div>  

</form>

</body>
</html>