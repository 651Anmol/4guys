<?php
require_once('connection.php');
if(isset($_GET['name'])){
    $name = $_GET['name'];
    $query = "DELETE FROM Cars where name = '$name';";
    mysqli_query($con, $query);
    header('location: main.php');
}
?>
